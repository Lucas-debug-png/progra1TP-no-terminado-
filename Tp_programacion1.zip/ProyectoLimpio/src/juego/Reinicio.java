package juego;

import java.awt.Image;

import javax.swing.ImageIcon;

import entorno.Entorno;

public class Reinicio {
	
	private Entorno entorno;
	
	private Image imagen;
	private boolean perder;
	
	public Reinicio(Entorno entorno) {
		
		this.entorno = entorno;
		this.perder = false;	
		this.imagen= new  ImageIcon("imagenes/game_over.png").getImage();
	}
	
	public void dibujar() {
		//mientras perder sea distinto de false, mientras sea true se va a activar la pantalla de perder
		
		if(!perder) {
			return;
		
		}
		
		entorno.dibujarImagen(imagen, 400, 250, 0);
		
		//entorno.dibujarImagen(imagen, 400, 250, 0, 1000);
		
		entorno.escribirTexto("Presiona R para reiniciar", 250, 350);
		
	}
	
	public boolean verificacion() {
		
		if(entorno.sePresiono('r') || entorno.sePresiono(entorno.TECLA_ENTER)) {
			return true;
		}
		
		return false;
		
		// aca verifica si perder es true y la tecla presionada es la R, esto sirve para que cuando aparezca la pantalla de reinicio y toquemos la letra R, iniciara todo el codigo
		
	}
	
	public void setter(boolean perder) {
		
		//perder es true
		this.perder= perder;
	}
	
	
	public boolean perdi() {
		
		//esto sirve para poder cambiar el valor de la variable en otros metodos
		return perder;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
