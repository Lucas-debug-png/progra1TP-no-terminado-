package juego;

import java.awt.Color;
import java.awt.Image;

import javax.swing.ImageIcon;

import entorno.Entorno;
import juego.Personaje.Gondolf;

public class Murcielago {
	
	private Entorno entorno;
	private Personaje personaje;
	private Gondolf gondolf;
	
	private double x;
	private double y;
	private int velocidad;
	private double angulo;
	private double ancho;
	private int alto;
	
	private Image imagen;

	public Murcielago(double angulo, double x, double y, int velocidad) {
		
		this.angulo= angulo;
		this.x=x;
		this.y=y;
		this.velocidad= velocidad;
		this.imagen = new ImageIcon("imagenes/gondolf_espalda.png").getImage();
		
		
	}
	
	public void mover() {
		
		
		y += velocidad * Math.sin(angulo);
		x += velocidad * Math.cos(angulo);
	
		
	}
	
	
	

	public boolean colision(double otroX, double otroY, Entorno entorno) {
		
		
	    boolean chocaIzquierda = otroX - (ancho ) < 10;
	    boolean chocaDerecha = otroX + (ancho -10) > 590; // evita el panel de la derecha
	    boolean chocaArriba = otroY - (alto +10) < 0;
	    boolean chocaAbajo = otroY + (alto) > 570;
		
		return chocaIzquierda || chocaDerecha || chocaArriba || chocaAbajo;
		
	}
	
	
	public void cambiarTrayectoria(Gondolf gondolf, double Dx, double Dy) {
		
		double Xpj= gondolf.getX();
		double Ypj= gondolf.getY();
		this.x= Dx;
		this.y= Dy;
		
		//obtenemos el angulo que debe seguir el mucielago

		double seguimiento = Math.atan2(Ypj-Dy , Xpj-Dx ); 
		
		while(Dx<= Xpj && Dy <= Dy) {
			
			Dx += seguimiento + Xpj;
			Dy += seguimiento + Ypj;
		}
		

	}
	
	
	public void acelerar() {
		velocidad += 0.05;
		
	}
		
	
	public void dibujar(Entorno entorno) {
		
		entorno.dibujarImagen(imagen, x+10, y+20, angulo, 1);
		
		if(this.imagen ==null) {
			System.out.println("la imagen esta vacia");
		}
		
		//entorno.dibujarImagen(imagen, x, y, angulo);
		
	}
	public double getX( ) {return x;}
	public double getY () {return y;}
	
}
