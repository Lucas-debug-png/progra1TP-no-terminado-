package juego;
import java.awt.Color;
import java.awt.Image;

import javax.swing.ImageIcon;

import entorno.Entorno;

public class Poderes {
	
	private Entorno entorno;
	private Image imagen;
	private double x;
	private double y;
	private double trayectoria;
	private double largo;
	private boolean laserActivo;
	private int tiempoVida;
	private final int TIEMPO_MAXIMO =30;  //creo una constante que sera el tiempo que se vera el laser;
	
	
	public  void Disparo (double x, double y, double angulo){
		
		
		this.x = x;
		this.y= y;
		this.trayectoria= angulo;
		this.largo= 1;
		this.laserActivo= true;
		this.tiempoVida = TIEMPO_MAXIMO;
		this.imagen= new ImageIcon("imagenes/Laser.png").getImage();
	}
	
	//tengo que actualizar el tiempo del poder y poner un limite y hasta cuando se vera
	public void actualizar() { 
		tiempoVida--;
		if(tiempoVida <0){
			laserActivo= false;
			
		}
	
		
	}

	public void dibujar(Entorno entorno) {
		
		if(!laserActivo) {
			return;
		}
		
		double xFinal= x + Math.cos(Math.toRadians(trayectoria)*largo);
		double yFinal = y + Math.cos(Math.toRadians(trayectoria)*largo);
		
		double Dx= x +xFinal;
		double Dy= y + yFinal;
		
		//calculamos la distancia usando pitagoras
		
		double distancia= Math.sqrt(Dx * Dx + Dy + Dy);
		
		entorno.dibujarImagen(imagen, xFinal/2, yFinal/2, 1.0);
		
		
		
	}
	
	
	
	
	public boolean estaActivo() {
		return laserActivo;
	}

	
}
