package juego;

import java.awt.Color;

import java.awt.Image;
import java.util.ArrayList;

import entorno.Entorno;
import entorno.Herramientas;
import entorno.InterfaceJuego;
import juego.Personaje.Gondolf;

public class Juego extends InterfaceJuego {
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	private Gondolf gondolf;
	private Roca roca;
	private Murcielago murcielago;
	private Image fondo;
	
	private ArrayList<Roca> rocas= new ArrayList<>();
	// Variables y métodos propios de cada grupo
	// ...

	Juego() {
		// Inicializa el objeto entorno
		
		this.fondo= fondo;
		entorno = new Entorno(this, "Gandalf el crocodrilo", 800, 600);
		
		fondo= Herramientas.cargarImagen("Fondo.jpg");
		
		
		
		rocas.add(new Roca(500, 300, entorno));
		rocas.add(new Roca(300, 200, entorno));
		
		gondolf = new Gondolf(400, 300, roca);
		
		murcielago= new Murcielago(100,200, 1, 2);
		
		
		// aca pueden entrar personajes, enemigos, obstaculos, puntos

		// Inicializar lo que haga falta para el juego
		// ...

		// Inicia el juego!
		this.entorno.iniciar();

	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y por lo
	 * tanto es el método más importante de esta clase. Aquí se debe actualizar el
	 * estado interno del juego para simular el paso del tiempo (ver el enunciado
	 * del TP para mayor detalle).
	 */
	public void tick() {

		entorno.dibujarImagen(fondo, 300, 300, 0);
		entorno.dibujarRectangulo(700, 300, 200, 600, 0, Color.DARK_GRAY); // menu en la part derecha de la pantalla 

		entorno.ancho();
		
		gondolf.mover(0, 0, entorno, roca, rocas);
		
		if(entorno.estaPresionada(entorno.TECLA_ESPACIO)) {
			gondolf.disparar();
		}
		
		gondolf.actualizarPoder();

		

		// entorno.dibujarRectangulo(x, y, Dy, Dx, Dy, null)

		//if (!gondolf.colision(entorno)) {
			
			
		
		//}
		
		
		gondolf.dibujarPj(entorno);
		
		murcielago.dibujar(entorno);
		murcielago.mover();
		
		murcielago.cambiarTrayectoria(gondolf, murcielago.getX(), murcielago.getY());
	
		
		for(Roca roca : rocas) {
			
			roca.dibujar(entorno);
		}
		
		gondolf.dibujarPoder(entorno);
		//roca.colisionConPj(gondolf);
		// Procesamiento de un instante de tiempo
		// ...

		
			

		
		
	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Juego juego = new Juego();
	}
}
