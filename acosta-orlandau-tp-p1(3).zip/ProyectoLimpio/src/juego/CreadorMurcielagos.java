package juego;

import java.awt.List;

import java.util.ArrayList;
import java.util.Iterator;


import entorno.Entorno;
import juego.Personaje.Gondolf;

public class CreadorMurcielagos {
	
	private Murcielago[] murcielagosTotal;
	private Murcielago[] murcielagosActivos;
	private ArrayList<Items> item;
	private Murcielago[] murcielagosActivos2;

	
	private boolean primeraHordaMuerta= false;
	private int oleadasCompletadas= 0;
	private int murcielagosMuertos=0;	
	
	private int totalDisponibles = 70;
	private int activosActuales = 0;
	
	private final int TOTAL_MURCIELAGO= 70;
	private final int MURCIELAGOS_X_OLEADA = 5;
	
	public CreadorMurcielagos() {
		
		murcielagosTotal= new Murcielago[TOTAL_MURCIELAGO];
		murcielagosActivos= new Murcielago[MURCIELAGOS_X_OLEADA];
		IniciaMurcielago();
	}
	
	private void IniciaMurcielago() {
		
		for(int i =0; i < murcielagosTotal.length; i++) {
			
			double x= -100;
			double y = -100;
			double angulo = Math.random() * 2 * Math.PI;
			
			murcielagosTotal[i]= new Murcielago( angulo, x , y,1);
			
		}
		activarOleada();
	}
	
	private void activarOleada() {
		if (totalDisponibles ==0) {
			return;
		}
		boolean murcielagoEncontrado = false;
		int cantidad= Math.min(5, totalDisponibles);
		
		for(int i= 0; i< cantidad; i++) {
			murcielagoEncontrado = false;
			
			if(activosActuales < murcielagosTotal.length) {
				
				for(int j=0; j <murcielagosTotal.length && !murcielagoEncontrado; j++) {
					
					if(murcielagosTotal[j] !=null) {
						
						Murcielago murcielago= murcielagosTotal[j];
						
						posicionesPantalla(murcielago);
						
						murcielago.sett_estaVivo(true);
						murcielagosActivos[activosActuales]= murcielago;
						activosActuales ++;
						
						murcielagosTotal[j]=null;
						totalDisponibles--;
						murcielagoEncontrado= true;
					}
				}
			}
			
//			Murcielago m= murcielagosTotal.remove(0);
//			posicionesPantalla(m);
//			murcielagosActivos.add(m);
//			
		}
	}
	
	
	
	public void posicionesPantalla(Murcielago murcielago) {
		
		int borde = (int) (Math.random()*4);
		
		if(borde==0) {
			murcielago.setPosicion(Math.random()*600,0);  //arriba
		}
		else if(borde==1) {
			murcielago.setPosicion(600, Math.random() *600); //derecha
		}
		else if(borde==2) {
			murcielago.setPosicion(Math.random()*600,600); // abajo
			
		}
		else {
			murcielago.setPosicion(0, Math.random()*600); //izquierda
		}
	}
	
	
	
	
	public void actualizar(Gondolf gondolf, Items[] itemsEnPantalla, Roca[] rocas) {
		
		
		
		
		for(int i=0; i< activosActuales; i++ ) {
	
			
			if(murcielagosActivos[i] !=null && murcielagosActivos[i].estaVivo() ) {
				
				murcielagosActivos[i].mover(gondolf);
				
				if(murcielagosActivos[i].colisionConPJ(gondolf)) {
					
					gondolf.quitarVida(10);
					
					murcielagosMuertos++;
					murcielagosActivos[i].sett_estaVivo(false);
					eliminarMurcielago(i);
					i--;
					
				
					
				}
			
		
			}
			
			
		}
		
		
		
		
		
		
//		while(iterador.hasNext()) {
//			Murcielago m= iterador.next();
//			m.mover(gondolf);
//			
//			if(m.colisionConPJ(gondolf)) {
//				
//				gondolf.quitarVida(10);
//				murcielagosMuertos++;
//				System.out.println("murcielagos muertos"+ murcielagosMuertos);
//				
//				iterador.remove();
//				
//
//				
//			}

		
		
		
		if(activosActuales==0 && totalDisponibles>0) {
			
			oleadasCompletadas++;
			
			
			double x= 200 + Math.random()*400;
			double y= 150+ Math.random()*300;
			boolean posicionValida= true;
			
			
			for(Roca roca: rocas) {
				
				if(Math.abs(roca.getX()-x)<50 && Math.abs(roca.getY()-y) <50) {
					
					posicionValida = false;
					
				}
			}
			
		
			
			
			
			if(posicionValida&&(!primeraHordaMuerta || oleadasCompletadas%2==0)) {
				
				
				Items nuevoItem = (Math.random() < 0.75) ? 
					//pocion de mana tiene 75 porciento de aparecer
					new Items(x,y,0,10) :
					new Items(x,y,15,0);
				
				
				for(int j=0; j< itemsEnPantalla.length; j++) {
					
				
					if(itemsEnPantalla[j]==null || itemsEnPantalla[j].isUsado()) {
						
						itemsEnPantalla[j]= nuevoItem;
						
					}
				}
				
				
				//itemsEnPantalla.add(new Items(x,y,20,0));
				//System.out.println("item generado en"+ x+ ", "+ y);
				//primeraHordaMuerta=true;
			}
			primeraHordaMuerta=true;
			activarOleada();
			System.out.println("oleanda numero: "+ oleadasCompletadas);
		}
	

	}
	
	


	public void eliminarMurcielago( int indice) {
		
		if (indice < 0 || indice >= activosActuales) return;

	    // Desplaza los elementos restantes
	    for (int i = indice; i < activosActuales - 1; i++) {
	        murcielagosActivos[i] = murcielagosActivos[i + 1];
	    }
	    murcielagosActivos[activosActuales - 1] = null; // Limpia la última posición
	    activosActuales--;
	}
	
	
	
	public boolean estaOcupada(double x , double y) {
		
		for(Murcielago  murcielago : murcielagosActivos) {
			
			double distancia = Math.sqrt((murcielago.getX() + murcielago.getX())* (murcielago.getY()+ murcielago.getY()));
	        if (distancia < 50) return true; // Radio mínimo de separación
	    }
	    return false;
			
		}
	
	
	
	
	public void dibujar(Entorno entorno) {
		  for(int i = 0; i < activosActuales; i++) {
		        if(murcielagosActivos[i] != null && murcielagosActivos[i].estaVivo()) {
		            murcielagosActivos[i].dibujar(entorno);
		        }
		    }
		}
	
	
	
	
	
	public Murcielago[] getMurcielagosActivos(){
		
		// TODO Auto-generated method stub
		 // 1. Contar murciélagos realmente activos
	    int contador = 0;
	    for(int i = 0; i < activosActuales; i++) {
	        if(murcielagosActivos[i] != null && murcielagosActivos[i].estaVivo()) {
	            contador++;
	        }
	    }
	    
	    // 2. Crear array del tamaño exacto
	    Murcielago[] resultado = new Murcielago[contador];
	    int index = 0;
	    
	    // 3. Llenar el array con los murciélagos activos
	    for(int i = 0; i < activosActuales; i++) {
	        if(murcielagosActivos[i] != null && murcielagosActivos[i].estaVivo()) {
	            resultado[index] = murcielagosActivos[i];
	            index++;
	        }
	    }
	    
	    return resultado;
	}
	

	
	
}


